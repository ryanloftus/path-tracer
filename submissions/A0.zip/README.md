# cs488

## a0

### Compilation

Compile and run with cmake and g++.

### Specification

Draws a moving cosine on the screen.