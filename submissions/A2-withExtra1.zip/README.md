# cs488

## a2

### Compilation

Compile and run with cmake and g++.

### Specification

You can pass an hdr file as the second cmd argument to use environment mapping. For example:

```
./CS488 media/teapot-metal.obj media/uffizi_probe.hdr
```

### Extras

Extra 1: SAH BVH is implemented. 

I benchmarked the performance using average runtime per frame for testObj-metal.obj:

- Without SAH: 3.06s
- With SAH: 1.43s

Therefore, the SAH implementation runs 53.27% faster.

