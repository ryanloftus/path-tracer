# cs488

## a1

### Compilation

Compile and run with cmake and g++.

### Specification

Task 2 can be tested by uncommenting the code inside the `rasterizeTriangle` function marked `TASK 2: get integer points and color them white`, and commenting out the entire second for loop in the `rasterizeTriangle` function.

Screenshots showing the result of each task are included as `a1_taskX_screenshot.png` (except for Task 1 which was given as starter code and displays nothing anyway).

