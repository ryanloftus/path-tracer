# cs488

## a2

### Compilation

Compile and run with cmake and g++.

### Specification

You can pass an hdr file as the second cmd argument to use environment mapping. For example:

```
./CS488 media/teapot-metal.obj media/uffizi_probe.hdr
```

